package com.dodieva.bookapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dodieva.bookapp.databinding.ActivityMyBookingsBinding

class MyBookingsActivity : AppCompatActivity() {

//    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMyBookingsBinding

    private lateinit var sessions: MutableList<GameSession>

    private var selectedSession = -1

    private lateinit var unBookButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMyBookingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        unBookButton = findViewById(R.id.button_unbook)

        // disabled by default
        unBookButton.isEnabled = false

        val app: MainApp = MainApp.instance
        val lightGreen = app.lightGreen
        val selectionColor = app.selectionColor

        sessions = mutableListOf()
        sessions.addAll(app.client.getMySessionsList())

        val timeSlots = findViewById<RecyclerView>(R.id.recyclerView_timeSlots)
        timeSlots.layoutManager = GridLayoutManager(this, 1)
        timeSlots.apply {
            // connect the adapter
            adapter = MyGameSessionAdapter(sessions, lightGreen, selectionColor){ position -> onListItemClick(position)}
        }

        unBookButton.setOnClickListener {

            val slot = sessions[selectedSession]
            if (app.client.tryUnBooking(slot.dateTime, selectedSession)) {
                Toast.makeText(this@MyBookingsActivity, "You un-booked ${slot.getFullDate()}", Toast.LENGTH_SHORT).show()

                // disable unbook button
                unBookButton.isEnabled = false
                sessions.removeAt(selectedSession)
                selectedSession = -1
            } else {
                Toast.makeText(this@MyBookingsActivity, "Un-booking failed!", Toast.LENGTH_SHORT).show()
            }
            timeSlots?.adapter?.notifyDataSetChanged()
        }

        // home button click
        binding.buttonHome.setOnClickListener {
            // probably not needed as we cannot be on this page if not logged in
//            if (!app.isUseLogged()) {
//                return@setOnClickListener
//            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

//        val navController = findNavController(R.id.nav_host_fragment_content_my_bookings)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }

    private fun onListItemClick(position: Int) {

        selectedSession = position
        unBookButton.isEnabled = selectedSession >= 0 && selectedSession < sessions.size
        //        val toast = Toast.makeText(this, sessions[position], Toast.LENGTH_SHORT)
//        toast.setGravity(Gravity.CENTER, 0, 0)
//        toast.show()
    }

//    override fun onRestart() {
//        super.onRestart()
//    }
//
//    override fun onResume() {
//        super.onResume()
//    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_my_bookings)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}