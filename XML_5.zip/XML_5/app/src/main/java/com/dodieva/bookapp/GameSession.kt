package com.dodieva.bookapp

import java.text.SimpleDateFormat
import java.util.*

class GameSession {
    var dateTime: Long = 0
    //var time: Long = 0

//    fun setDate(dateTime: String) {
//        val date = Date(dateTime)
//        val format = SimpleDateFormat("yyyy.MM.dd HH:mm")
//        return format.format(date)
//    }

    fun getFullDate() : String {
        val date = Date(dateTime)
        val format = SimpleDateFormat("yyyy.MM.dd HH:mm")
        return format.format(date)
    }

    fun getDate() : String {
        val date = Date(dateTime)
        val format = SimpleDateFormat("yyyy.MM.dd")
        return format.format(date)
    }

    fun getTime() : String {
        val date = Date(dateTime)
        val format = SimpleDateFormat("HH:mm")
        return format.format(date)
    }

//    fun setTime(date: String) {
//
//    }
//
//    fun getTime() : String {
//
//    }
//    var date: String = ""
//    var time: String = ""
}