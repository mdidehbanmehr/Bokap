package com.dodieva.bookapp

import android.app.Application
import android.os.Build
import androidx.annotation.RequiresApi

class MainApp : Application() {
    private var userName: String = ""
    private var userId: String = ""

    var lightGreen: Int = 0
    var selectionColor: Int = 0

    // we possible should pass the IP of the server here
    lateinit var client: Client//Client("")

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate() {
        super.onCreate()
        client = Client("")
        instance = this

        // TODO: comment this line in the final app!
        client.testMode = true

        // Read colors from resources
        lightGreen = resources.getColor(
            resources.getIdentifier(
                "lightgreen",
                "color",
                packageName
            ), theme
        )

        selectionColor = resources.getColor(
            resources.getIdentifier(
                "selectionColor",
                "color",
                packageName
            ), theme
        )
    }

    fun isUseLogged(): Boolean {
        return !userName.isNullOrEmpty()
    }

    fun setUser(name: String, id: String) {
        this.userName = name
        this.userId = id
    }

    fun logOut() {
        client.logOut(userName)
        this.userName = ""
        this.userId = ""
    }

    companion object {
        lateinit var instance: MainApp
            private set
    }
}