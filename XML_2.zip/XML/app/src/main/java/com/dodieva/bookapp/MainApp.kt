package com.dodieva.bookapp

import android.app.Application
import android.os.Build
import androidx.annotation.RequiresApi

class MainApp : Application() {
    private var userName: String? = null
    private var userId: String? = null

    var lightGreen: Int = 0

    fun setUser(name: String, id: String) {
        this.userName = name
        this.userId = id
    }

    fun isUseLogged(): Boolean {
        return !userName.isNullOrEmpty()
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate() {
        super.onCreate()
        instance = this

        lightGreen = resources.getColor(
            resources.getIdentifier(
                "lightgreen",
                "color",
                packageName
            ), theme)
    }

    companion object {
        lateinit var instance: MainApp
            private set
    }}