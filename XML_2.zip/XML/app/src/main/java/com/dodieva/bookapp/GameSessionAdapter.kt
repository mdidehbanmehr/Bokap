package com.dodieva.bookapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// The adapter class for the RecyclerView
class GameSessionAdapter(private val items: List<String>,
                         private val lightgreen: Int,
                         private val onItemClicked: (position: Int) -> Unit) :
    RecyclerView.Adapter<GameSessionAdapter.MyViewHolder>(){

    private var selectedItemPosition: Int = 0

    // resource optimization
    class MyViewHolder(itemView: View,
                       private val onItemClicked: (position: Int) -> Unit) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {

        // Text View control associated with the session time
        var timeTextView: TextView? = null

        init {
            // initialize the reference to the Text View
            timeTextView = itemView.findViewById(R.id.textViewLarge)

            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            onItemClicked(position)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.game_session_item, parent, false)
        return MyViewHolder(itemView, onItemClicked)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.timeTextView?.text = items[position]
        //*
        holder.itemView.setOnClickListener {
            selectedItemPosition = holder.adapterPosition
            onItemClicked(position)
            notifyDataSetChanged()
        }

        if(selectedItemPosition == position)
            holder.timeTextView?.setBackgroundColor(Color.parseColor("#DC746C"))
        else
            holder.timeTextView?.setBackgroundColor(lightgreen)
        //*/
    }

    override fun getItemCount() = items.size
}