package com.dodieva.bookapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dodieva.bookapp.databinding.ActivityMyBookingsBinding

class MyBookingsActivity : AppCompatActivity() {

//    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMyBookingsBinding

    private lateinit var sessions: List<String>

    private var selectedSession: Int = -1

    private lateinit var unbookButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMyBookingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        unbookButton = findViewById(R.id.button_unbook)

        // disabled by default
        unbookButton.isEnabled = false

        val app: MainApp = MainApp.instance
        val lightgreen = app.lightGreen
//        val lightgreen = resources.getColor(
//            resources.getIdentifier(
//                "lightgreen",
//                "color",
//                packageName
//            ), theme)

        sessions = fillSessionsList()

        val timeSlots = findViewById<RecyclerView>(R.id.recyclerView_timeSlots)
        timeSlots.layoutManager = GridLayoutManager(this, 1)
        timeSlots.apply {
            // connect the adapter
            adapter = GameSessionAdapter(sessions, lightgreen){position -> onListItemClick(position)}
        }

        // home button click
        binding.buttonHome.setOnClickListener {
            if (!app.isUseLogged()) {
                return@setOnClickListener
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

//        val navController = findNavController(R.id.nav_host_fragment_content_my_bookings)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }

    private fun onListItemClick(position: Int) {
        selectedSession = position

        if (selectedSession >= 0 && selectedSession < sessions.size) {
            unbookButton.isEnabled = true
        } else {
            unbookButton.isEnabled = false
        }
        //        val toast = Toast.makeText(this, sessions[position], Toast.LENGTH_SHORT)
//        toast.setGravity(Gravity.CENTER, 0, 0)
//        toast.show()
    }

    private fun fillSessionsList(): List<String> {
        val data = mutableListOf<String>()
        (9..12).forEach { i -> data.addAll(listOf("$i:00 court #1", "$i:30 court #2")) }
        return data
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_my_bookings)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}