package com.dodieva.bookapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.dodieva.bookapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    //private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityLoginBinding
    private var userName: String = ""
    private var userPassword : String = ""

    private lateinit var loginButton: Button
    private lateinit var loginError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val userNameE = findViewById<EditText>(R.id.username_input)
        val userPasswordE = findViewById<EditText>(R.id.password_input)

        loginButton = findViewById(R.id.button_login)
        loginError = findViewById(R.id.textView_login_error)

        // error is not visible now
        loginError.isVisible = false

        // sign-up button is disabled
        loginButton.isEnabled = false

        val app: MainApp = MainApp.instance

        // home button click
        binding.buttonHome.setOnClickListener {
            if (!app.isUseLogged()) {
                return@setOnClickListener
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

//        val userName = findViewById<EditText>(R.id.username_input)
//        val userPassword = findViewById<EditText>(R.id.password_input)
//        val loginButton = findViewById<Button>(R.id.button_login)
        val signUpButton = findViewById<Button>(R.id.button_signin)

        loginButton.setOnClickListener {
            // TODO: connect to the server and check the login possibility
//            if (server_cannot_login) {
//                loginError.text = "Invalid user name or password! Cannot login!"
//                loginError.isVisible = true
//                return@setOnClickListener
//            }

            app.setUser(userName, "")

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        signUpButton.setOnClickListener {
            val intent = Intent(this, SigninActivity::class.java)
            startActivity(intent)
        }

        userNameE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                userName = if (s.isNotEmpty()) s.toString() else ""
                checkLoginCredentials()
            }
        })
        userPasswordE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                userPassword = if (s.isNotEmpty()) s.toString() else ""
                checkLoginCredentials()
            }
        })

//        val navController = findNavController(R.id.nav_host_fragment_content_login)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }

    private fun checkLoginCredentials() {
        if (userName.isEmpty() ||
            userPassword.isEmpty()) {

            loginError.text = "All fields must be filled!"
            loginError.isVisible = true
            loginButton.isEnabled = false
            return
        }

        // Check email is ok
        if (!Patterns.EMAIL_ADDRESS.matcher(userName).matches()) {
            loginError.text = "Invalid user name! Should be the user email address!"
            loginError.isVisible = true
            loginButton.isEnabled = false
            return
        }

        loginError.isVisible = false
        loginButton.isEnabled = true
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_login)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}