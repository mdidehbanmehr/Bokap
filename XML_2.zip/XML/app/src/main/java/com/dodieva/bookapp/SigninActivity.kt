package com.dodieva.bookapp

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.dodieva.bookapp.databinding.ActivitySigninBinding
import android.text.Editable

import android.text.TextWatcher

class SigninActivity : AppCompatActivity() {

    //private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivitySigninBinding

    private var firstName: String = ""
    private var lastName: String = ""
    private var userEmail: String = ""
    private var userPassword : String = ""
    private var confirmUserPassword: String = ""

    private lateinit var signupButton: Button
    private lateinit var signupError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySigninBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val firstNameE = findViewById<EditText>(R.id.firstname_input)
        val lastNameE = findViewById<EditText>(R.id.lastname_input)
        val userEmailE = findViewById<EditText>(R.id.email_input)
        val userPasswordE = findViewById<EditText>(R.id.password_input)
        val confirmUserPasswordE = findViewById<EditText>(R.id.password_confirm_input)

        signupButton = findViewById(R.id.button_signup)
        signupError = findViewById(R.id.textView_signup_error)

        // error is not visible now
        signupError.isVisible = false

        // sign-up button is disabled
        signupButton.isEnabled = false

        firstNameE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                firstName = if (s.isNotEmpty()) s.toString() else ""
                checkUserCredentials()
            }
        })
        lastNameE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                lastName = if (s.isNotEmpty()) s.toString() else ""
                checkUserCredentials()
            }
        })
        userEmailE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                userEmail = if (s.isNotEmpty()) s.toString() else ""
                checkUserCredentials()
            }
        })
        userPasswordE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                userPassword = if (s.isNotEmpty()) s.toString() else ""
                checkUserCredentials()
            }
        })
        confirmUserPasswordE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                confirmUserPassword = if (s.isNotEmpty()) s.toString() else ""
                checkUserCredentials()
            }
        })

        signupButton.setOnClickListener {
            // TODO: check with the server that we are OK to create a user with given credentials

            val app: MainApp = MainApp.instance
            app.setUser(userEmail, "")

            signupError.isVisible = false

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

//        val navController = findNavController(R.id.nav_host_fragment_content_signin)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }

    private fun checkUserCredentials() {
        if (firstName.isEmpty() ||
            lastName.isEmpty() ||
            userEmail.isEmpty() ||
            userPassword.isEmpty() ||
            confirmUserPassword.isEmpty()) {

            signupError.text = "All fields must be filled!"
            signupError.isVisible = true
            signupButton.isEnabled = false
            return
        }

        // Check email is ok
        if (!Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
            signupError.text = "Invalid email address!"
            signupError.isVisible = true
            signupButton.isEnabled = false
            return
        }

        if (userPassword != confirmUserPassword) {
            signupError.text = "Password should match!"
            signupError.isVisible = true
            signupButton.isEnabled = false
            return
        }

        signupError.isVisible = false
        signupButton.isEnabled = true
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_signin)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}