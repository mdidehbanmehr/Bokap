package com.example.bokap;

import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

import android.content.ClipData;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Calendar_activity extends AppCompatActivity {
    private Button btn_c_0900;
    private Button getBtn_c_1100;
    private Button btn_c_1300;
    private Button getBtn_c_1500;
    private Button btn_p_0900;
    private Button getBtn_p_1100;
    private Button btn_p_1300;
    private Button getBtn_p_1500;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        btn_c_0900 = (Button) findViewById(R.id.btn_0900_practise);
        btn_c_0900.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreatePopup();
            }
        });
    }

    public void CreatePopup() {
        LinkedList timesCourtsPractise = new LinkedList<>();

    }
}