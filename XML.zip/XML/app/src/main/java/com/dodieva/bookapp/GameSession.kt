package com.dodieva.bookapp

class GameSession {
    //public DateTime: Date
}