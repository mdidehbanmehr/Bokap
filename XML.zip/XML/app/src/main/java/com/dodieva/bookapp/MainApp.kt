package com.dodieva.bookapp

import android.app.Application

class MainApp : Application() {
    private var userName: String? = null
    private var userId: String? = null

    public fun setUser(name: String, id: String) {
        this.userName = name
        this.userId = id
    }

    public fun isUseLogged(): Boolean {
        return !userName.isNullOrEmpty()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: MainApp
            private set
    }}