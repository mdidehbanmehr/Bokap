package com.dodieva.bookapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.dodieva.bookapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    //private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val app: MainApp = MainApp.instance

        // home button click
        binding.buttonHome.setOnClickListener {
            if (!app.isUseLogged()) {
                return@setOnClickListener
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val userName = findViewById<EditText>(R.id.username_input)
        val userPassword = findViewById<EditText>(R.id.password_input)
        val loginButton = findViewById<Button>(R.id.button_login)
        val signinButton = findViewById<Button>(R.id.button_signin)

        loginButton.setOnClickListener {
            if (userName.text.isNullOrEmpty() || userPassword.text.isNullOrEmpty()) return@setOnClickListener

            app.setUser(userName.text.toString(), "")

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        signinButton.setOnClickListener {
            val intent = Intent(this, SigninActivity::class.java)
            startActivity(intent)
        }

//        val navController = findNavController(R.id.nav_host_fragment_content_login)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_login)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }

}