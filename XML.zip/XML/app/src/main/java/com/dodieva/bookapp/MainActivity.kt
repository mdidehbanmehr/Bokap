package com.dodieva.bookapp

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.widget.CalendarView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dodieva.bookapp.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    private lateinit var sessions: List<String>

    private var selectedSession: Int = -1

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
/*
        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)
        */
        /*
        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
        }
        */

        binding.calendarView.setOnDateChangeListener { calView: CalendarView, year: Int, month: Int, dayOfMonth: Int ->

            // Create calender object with which will have system date time.
            val calender: Calendar = Calendar.getInstance()

            // Set attributes in calender object as per selected date.
            calender.set(year, month, dayOfMonth)

            // Now set calenderView with this calender object to highlight selected date on UI.
            calView.setDate(calender.timeInMillis, true, true)
            Log.d("SelectedDate", "$dayOfMonth/${month + 1}/$year")
        }

        val lightgreen = resources.getColor(
            resources.getIdentifier(
                "lightgreen",
                "color",
                packageName
            ), theme)

        sessions = fillSessionsList()

        val recyclerView: RecyclerView = binding.recyclerViewTimeSlots
        //recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.apply {
            // connect the adapter
            adapter = GameSessionAdapter(sessions, lightgreen){position -> onListItemClick(position)}
        }
        //recyclerView.adapter = GameSessionAdapter(fillSessionsList())

        // set on-click listener
        binding.buttonBook.setOnClickListener {
            if (selectedSession >= 0)
                Toast.makeText(this@MainActivity, "You booked ${sessions[selectedSession]}", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(this@MainActivity, "Select time slot", Toast.LENGTH_SHORT).show()
        }

        //val app: MainApp = applicationContext as MainApp
        val app: MainApp = MainApp.instance

        if (app.isUseLogged()) {

        }
        else {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
        //binding.mainLayout.isVisible = app.isUseLogged()
//        binding.txtPickUpDrop.isVisible = false
//        binding.recyclerViewTimeSlots.isVisible = false
//        binding.button.isVisible = false

        // login button click
        binding.buttonTb1.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        // signin button click
        binding.buttonTb2.setOnClickListener {
            val intent = Intent(this, SigninActivity::class.java)
            startActivity(intent)
        }

//        // home button click
//        binding.buttonHome.setOnClickListener {
//            val intent = Intent(this, MainActivity::class.java)
//            startActivity(intent)
//        }
    }

    private fun onListItemClick(position: Int) {
        selectedSession = position
    //        val toast = Toast.makeText(this, sessions[position], Toast.LENGTH_SHORT)
//        toast.setGravity(Gravity.CENTER, 0, 0)
//        toast.show()
    }

    private fun fillSessionsList(): List<String> {
        val data = mutableListOf<String>()
        (9..12).forEach { i -> data.addAll(listOf("$i:00 court #1", "$i:30 court #2")) }
        return data
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}