package com.dodieva.bookapp

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.CalendarView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dodieva.bookapp.databinding.ActivityMainBinding
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    private lateinit var sessions: MutableList<String>

    private var selectedSession: Int = -1

    private var year: Int = 0
    private var month: Int = 0
    private var dayOfMonth: Int = 0

    private lateinit var bookButton: Button

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bookButton = findViewById(R.id.button_book)

        // disabled by default
        bookButton.isEnabled = false

//        setSupportActionBar(binding.toolbar)
//
//        val navController = findNavController(R.id.nav_host_fragment_content_main)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                    .setAction("Action", null).show()
//        }

        val app: MainApp = MainApp.instance
        val lightGreen = app.lightGreen
        val selectionColor = app.selectionColor

        val df: DateFormat = SimpleDateFormat("dd/MM/yyyy")
        val today = Date(binding.calendarView.date)
        sessions = mutableListOf()
        sessions.addAll(app.client.getSessionsList(df.parse(df.format(today)).time))
        //sessions = app.client.getSessionsList(df.parse(df.format(today)).time)

        val timeSlots: RecyclerView = binding.recyclerViewTimeSlots
        //recyclerView.layoutManager = LinearLayoutManager(this)
        timeSlots.layoutManager = GridLayoutManager(this, 2)
        timeSlots.apply {
            // connect the adapter
            adapter = GameSessionAdapter(sessions, lightGreen, selectionColor){ position -> onListItemClick(position)}
        }

        // Create calender object with which will have system date time.
        val calender: Calendar = Calendar.getInstance()

        this.year = calender.get(Calendar.YEAR)
        this.month = calender.get(Calendar.MONTH)
        this.dayOfMonth = calender.get(Calendar.DAY_OF_MONTH)

        binding.calendarView.setOnDateChangeListener { calView: CalendarView, year: Int, month: Int, dayOfMonth: Int ->

            this.year = year
            this.month = month
            this.dayOfMonth = dayOfMonth

            // Set attributes in calender object as per selected date.
            calender.set(year, month, dayOfMonth)

            // Now set calenderView with this calender object to highlight selected date on UI.
            calView.setDate(calender.timeInMillis, true, true)
            Log.d("SelectedDate", "$dayOfMonth/${month + 1}/$year")

            // clear the sessions list
            sessions.clear()

            // get a new list from the server
            sessions.addAll(app.client.getSessionsList(calView.date))

            // reset the session selection
            selectedSession = -1

            timeSlots?.adapter?.notifyDataSetChanged()
        }

        // set on-click listener
        bookButton.setOnClickListener {

            val slotTime = sessions[selectedSession]

            val df = SimpleDateFormat("HH:mm")
            calender.time = df.parse(slotTime)
            calender.set(year, month, dayOfMonth)
            val time = calender.time.time
            if (app.client.tryBooking(time, selectedSession)) {
                Toast.makeText(this@MainActivity, "You booked $slotTime", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, "Booking failed! Try another slot", Toast.LENGTH_SHORT).show()
            }
        }

        // logout button click
        binding.buttonLogout.setOnClickListener {
            // logout
            app.logOut()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        // my bookings button click
        binding.buttonMyBookings.setOnClickListener {
            val intent = Intent(this, MyBookingsActivity::class.java)
            startActivity(intent)
        }

        // just in case check that the user is logged in
        if (!app.isUseLogged()) {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun onListItemClick(position: Int) {

        selectedSession = position
        bookButton.isEnabled = selectedSession >= 0 && selectedSession < sessions.size

        //        val toast = Toast.makeText(this, sessions[position], Toast.LENGTH_SHORT)
//        toast.setGravity(Gravity.CENTER, 0, 0)
//        toast.show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}