package com.dodieva.bookapp

import kotlin.random.Random

class Client(ipAddress: String) {

    // only for test
    private val mySessions: MutableList<GameSession> = mutableListOf()

    // only for test
    private val dateSessions: MutableList<String> = mutableListOf()

    // True if we are testing the app, False - we should use the real http access
    var testMode: Boolean = false
    private var userEmail: String = ""

    // Returns true if the user could login successfully with give name and password
    fun tryLoginUser (userName:String, userPassword:String) : Boolean {
        if (testMode) {
            mySessions.clear()
            userEmail = userName
            return true
        }

        // userEmail = userName
        // return false
        TODO ("Not yet implemented: checkUserLogin")
    }

    // Signs up a new user
    // If success then return an empty string
    // If failure then return error string to show to the user
    fun trySignUpNewUser(
        firstName: String,
        lastName: String,
        userEmail: String,
        userPassword: String
    ): String {

        if (testMode) {
            mySessions.clear()
            this.userEmail = userEmail
            return ""
        }

        // this.userEmail = userEmail
        // return "Cannot register the user!"
        TODO ("Not yet implemented: signUpNewUser")
    }

    // for the give date
    fun getSessionsList(date: Long): MutableList<String> {
        if (testMode) {
            dateSessions.clear()
            val rnd = Random(date)
            for (i in 9..17) {
                if (rnd.nextInt(100) > 25) dateSessions.add("$i:00 court #1")
                if (rnd.nextInt(100) > 25) dateSessions.add("$i:30 court #2")
            }
            return dateSessions
            //val values = List(10) { rnd.nextInt(2*9, 2*17) }
            //values.forEach { i -> if (0 == i%2) sessions.add("${i/2}:00 court #1") else sessions.add("${i/2}:30 court #2")  }
            //val data = mutableListOf<String>()
            //(9..12).forEach { i -> sessions.addAll(listOf("$i:00 court #1", "$i:30 court #2")) }
        }

        TODO("Not yet implemented: getSessionsList")
    }

    // for the give date
    fun getMySessionsList(): MutableList<GameSession> {
        if (testMode) {
            return mySessions
        }

        TODO("Not yet implemented: getSessionsList")
    }

    fun logOut(userName: String) {
        if (testMode) {
            mySessions.clear()
            this.userEmail = ""
            return
        }

        // this.userEmail = ""
        TODO("Not yet implemented: logOut")
    }

    //fun tryBooking(slotDate: String, slotTime: String, slotId: Int): Boolean {
    fun tryBooking(dateTime: Long, slotId: Int): Boolean {
        if (testMode) {
            val slot = GameSession()
            slot.dateTime = dateTime
            //slot.time = slotTime
            if (mySessions.filter { it.dateTime == dateTime }.size == 1)
                return false
            mySessions.add(slot)
            return true
        }

        TODO("Not yet implemented: tryBooking")
    }

    //fun tryUnBooking(slotDate: String, slotTime: String, slotId: Int): Boolean {
    fun tryUnBooking(dateTime: Long, slotId: Int): Boolean {
        if (testMode) {
            if (slotId >= 0 && slotId < mySessions.size) {
                mySessions.removeAt(slotId)
            }
            return true
        }

        TODO("Not yet implemented: tryUnBooking")
    }
}