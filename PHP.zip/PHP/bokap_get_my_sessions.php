<?php

//Convert time to Java that is in milliseconds
// We multiply by 1000 the PHP time that is in seconds
$bookings = array(strtotime('2021-12-20 10:00')*1000, strtotime('2021-12-20 12:00')*1000);

$temp = [
    'id' => '0',
    'bookings' => $bookings
    ];

echo json_encode($temp);