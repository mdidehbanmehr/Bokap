<?php

$json = [
    'id' => '0',
    'date' => '2021-12-10',
    'time' => '10:00'
];

echo json_encode($json);
