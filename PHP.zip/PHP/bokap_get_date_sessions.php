<?php

$date = new DateTime('now');
// Java time is in milliseconds, convert to PHP that is in seconds
$date = $date->format("Y-m-d");

$slots = array("9:00", "9:30");

$user = [
    'id' => '1',
    'date' => $date,
    'slots' => $slots
];

echo json_encode($user);