<?php

$json = [
    'id' => '0',
    'unique_id' => 'unique_id_generated',
    'name' => 'James',
    'last' => 'Bond'
];

echo json_encode($json);