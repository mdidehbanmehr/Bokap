<?php

$json = [
    'id' => '0',
    'unique_id' => 'unique_id_generated'
];

echo json_encode($json);