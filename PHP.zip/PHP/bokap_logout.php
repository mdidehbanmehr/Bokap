<?php

$json = [
    'id' => '0'
];

echo json_encode($json);